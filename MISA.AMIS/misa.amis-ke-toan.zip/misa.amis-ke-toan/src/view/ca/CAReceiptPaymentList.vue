<template>
  <div class="CAReceiptPaymentList">
      
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>